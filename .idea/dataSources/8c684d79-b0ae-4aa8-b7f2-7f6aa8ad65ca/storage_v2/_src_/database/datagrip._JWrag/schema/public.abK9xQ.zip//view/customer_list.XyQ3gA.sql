create view customer_list(id, name, address, "zip code", phone, city, country, notes, sid) as
SELECT cu.customer_id                                           AS id,
       (cu.first_name::text || ' '::text) || cu.last_name::text AS name,
       a.address,
       a.postal_code                                            AS "zip code",
       a.phone,
       city.city,
       country.country,
       CASE
           WHEN cu.activebool THEN 'active'::text
           ELSE ''::text
           END                                                  AS notes,
       cu.store_id                                              AS sid
FROM customer cu
         JOIN address a ON cu.address_id = a.address_id
         JOIN city ON a.city_id = city.city_id
         JOIN country ON city.country_id = country.country_id;

alter table customer_list
    owner to postgres;

grant select on customer_list to datagrip;

